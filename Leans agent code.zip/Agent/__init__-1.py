import logging
import sys
from logging import StreamHandler

from .log_config import fetch_log_config
from .file_handler import create_file_handler, _get_formatter
from .queue_handler import OrchestratorQueueHandler


# Module-level reference so agent can call shutdown on exit
_orchestrator_handler: OrchestratorQueueHandler | None = None


def setup_logging(
    orchestrator_base_url: str,
    agent_id: str,
    execution_id: str,
    log_dir: str = "logs",
    failed_log_file: str = "logs/failed_logs.jsonl",
) -> logging.Logger:
    """
    Full logging bootstrap for the agent:

    1. Fetches log_level + flush config from orchestrator
    2. Configures:
       - Console handler (stdout)
       - Rotating file handler
       - Orchestrator queue handler (batches + ships logs)
    3. Returns the root logger ready to use

    Call shutdown_logging() when agent execution completes.
    """
    global _orchestrator_handler

    # ------------------------------------------------------------------ #
    # Step 1: Fetch config from orchestrator                               #
    # ------------------------------------------------------------------ #
    config = fetch_log_config(orchestrator_base_url, agent_id)

    log_level = config["log_level_int"]
    interval_seconds = config["log_flush_interval_seconds"]
    batch_size = config["log_flush_batch_size"]

    # ------------------------------------------------------------------ #
    # Step 2: Build handlers                                               #
    # ------------------------------------------------------------------ #

    # Console
    console_handler = StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(_get_formatter())

    # Rotating file - always DEBUG so nothing is lost locally
    file_handler = create_file_handler(
        log_dir=log_dir,
        log_level=logging.DEBUG,
    )

    # Orchestrator queue handler
    _orchestrator_handler = OrchestratorQueueHandler(
        orchestrator_base_url=orchestrator_base_url,
        agent_id=agent_id,
        execution_id=execution_id,
        interval_seconds=interval_seconds,
        batch_size=batch_size,
        failed_log_file=failed_log_file,
    )
    _orchestrator_handler.setLevel(log_level)
    _orchestrator_handler.setFormatter(_get_formatter())

    # ------------------------------------------------------------------ #
    # Step 3: Configure root logger                                        #
    # ------------------------------------------------------------------ #
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Let handlers filter their own levels

    # Remove any existing handlers (avoid duplicates on re-init)
    root_logger.handlers.clear()

    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(_orchestrator_handler)

    root_logger.info(
        f"Logging initialized | agent_id={agent_id} | execution_id={execution_id} | "
        f"level={config['log_level']} | flush_interval={interval_seconds}s | "
        f"batch_size={batch_size}"
    )

    return root_logger


def shutdown_logging():
    """
    Call this when agent execution is complete.
    Ensures all queued logs are flushed to orchestrator before process exits.
    """
    global _orchestrator_handler
    if _orchestrator_handler:
        logging.getLogger().info("Shutting down logging - flushing remaining logs...")
        _orchestrator_handler.shutdown()
        _orchestrator_handler = None
